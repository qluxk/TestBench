# License Status

This package is provided for private research transfer only.

No public redistribution license has been selected. Before releasing the dataset, the owner must choose a license, confirm that all generated content and third-party components can be distributed under it, and update this file with the final terms.

Until then, do not upload the archive to a public repository, dataset hub, or paper artifact site.
