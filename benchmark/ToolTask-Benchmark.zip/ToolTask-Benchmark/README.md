# ToolTask Benchmark Transfer Package

This is a private research-transfer package for running additional experiments and drafting a benchmark paper. It is not yet cleared for public redistribution.

## Contents

- `data/tasks/tasks.jsonl`: 2000 synthetic tool-use task instances.
- `scripts/virtual_tool_runtime.py`: offline executable environment for the task tools.
- `data/trajectories/trajectories.jsonl`: 2218 sanitized trajectories aligned one-to-one with the graph pool.
- `data/graphs/normal/`: 1521 normal semantic trajectory graphs.
- `data/graphs/abnormal/`: 697 abnormal semantic trajectory graphs.
- `splits/official_split.json`: the frozen train/validation/test protocol plus an unused graph pool.
- `metadata/graph_pool.jsonl`: one index row per packaged graph.
- `metadata/dataset_manifest.json`: package counts, vocabulary, and privacy decisions.
- `DATA_CARD.md`: task definition, labels, known limitations, and responsible-use notes.
- `BENCHMARK_PAPER_BRIEF.md`: a claim-to-evidence plan for a benchmark paper.
- `PROMPTS.md`: the complete label-blind two-stage semantic edge prompts.
- `scripts/trajectory_to_nodes.py`: deterministic trajectory-to-node conversion.
- `scripts/build_semantic_dags.py`: provider-neutral two-stage semantic DAG builder.
- `scripts/audit_semantic_dags.py`: graph structure and invariance audit.
- `config/graph_builder.example.json`: API-neutral graph-builder configuration.
- `examples/`: a small trajectory, mock stage responses, and expected graph.
- `MANIFEST.sha256`: checksums for all packaged files.
- `scripts/validate_package.py`: offline integrity validator.

## Quick validation

```bash
python3 scripts/validate_package.py
sha256sum -c MANIFEST.sha256
```

## Execute the virtual-tool tasks

The runtime exposes task schemas without labels or hidden records, executes read tools
against the records embedded in each task, and returns deterministic simulated receipts
for state-changing tools. It performs no network calls or real-world side effects.

```bash
python3 scripts/virtual_tool_runtime.py list --limit 5
python3 scripts/virtual_tool_runtime.py show \
  --sample-id sample_8c69bbd8664c935af865
python3 scripts/virtual_tool_runtime.py run-plan \
  --sample-id sample_8c69bbd8664c935af865 \
  --plan examples/virtual_tool_plan.json
```

The Python API provides `TaskCatalog`, `VirtualToolSession`, `public_task`, and
`virtual_result` for integration with another agent runner.

## Rebuild semantic graphs

The graph builder uses an OpenAI-compatible chat-completions endpoint without embedding credentials in files:

```bash
export LLM_API_KEY="..."
python3 scripts/build_semantic_dags.py \
  --input data/trajectories/trajectories.jsonl \
  --output-dir rebuilt-graphs \
  --config config/graph_builder.example.json
python3 scripts/audit_semantic_dags.py rebuilt-graphs
```

For an offline smoke test that makes no API request:

```bash
python3 scripts/build_semantic_dags.py \
  --input examples/trajectory_example.jsonl \
  --output-dir example-output \
  --mock-backbone examples/backbone_response.json \
  --mock-expansion examples/expansion_response.json
```

## Benchmark tasks

The package supports three related evaluation settings:

1. **Task-record classification** using the model-visible task and tool records.
2. **Trajectory-level anomaly detection** using complete execution traces.
3. **Semantic-graph anomaly detection and localization** using typed nodes and directed semantic edges.

The official split is the primary comparable protocol. The `unused_pool` is retained for alternative class ratios, stress tests, or future benchmark tracks and must not be silently mixed into the official test set.

## Important boundaries

- Labels describe observed trajectory outcomes, not merely attack exposure.
- Synthetic names, addresses, tokens, and account-like identifiers are scenario content, not real credentials.
- Model-provider metadata, token usage, local paths, private audits, checkpoints, logs, and result files were excluded.
- The archive contains no baseline scores or unpublished experiment results.
- A release license and final public documentation must be chosen before publication.
