#!/usr/bin/env python3
"""Offline runtime for executing ToolTask's synthetic virtual tools.

The runtime never connects to external services and never performs real-world
state changes. Read tools return records embedded in the selected task. Write
tools return deterministic simulated-operation receipts.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path
from typing import Any


JSON_TYPES = {
    "object": dict,
    "array": list,
    "string": str,
    "integer": int,
    "number": (int, float),
    "boolean": bool,
    "null": type(None),
}


def read_jsonl(path: Path) -> list[dict[str, Any]]:
    rows: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            value = json.loads(line)
            if not isinstance(value, dict):
                raise ValueError(f"Expected an object at {path}:{line_number}")
            rows.append(value)
    return rows


def public_task(task: dict[str, Any]) -> dict[str, Any]:
    """Return the model-visible task without hidden records or labels."""
    return {
        "sample_id": task["sample_id"],
        "domain": task["domain"],
        "task": task["task"],
        "available_tools": [
            {key: value for key, value in tool.items() if key != "data"}
            for tool in task["tools"]
        ],
    }


class TaskCatalog:
    def __init__(self, path: Path):
        self.path = path
        rows = read_jsonl(path)
        self.by_id = {str(row["sample_id"]): row for row in rows}
        if len(self.by_id) != len(rows):
            raise ValueError("Duplicate sample_id in task catalog")

    def get(self, sample_id: str) -> dict[str, Any]:
        try:
            return self.by_id[sample_id]
        except KeyError as exc:
            raise KeyError(f"Unknown sample_id: {sample_id}") from exc

    def list(self, limit: int | None = None) -> list[dict[str, Any]]:
        rows = [
            {
                "sample_id": row["sample_id"],
                "domain": row["domain"],
                "tool_count": len(row["tools"]),
            }
            for row in self.by_id.values()
        ]
        rows.sort(key=lambda row: row["sample_id"])
        return rows if limit is None else rows[:limit]


def validate_value(value: Any, schema: dict[str, Any], path: str = "arguments") -> None:
    expected = schema.get("type")
    if isinstance(expected, list):
        errors = []
        for candidate in expected:
            try:
                validate_value(value, {**schema, "type": candidate}, path)
                return
            except ValueError as exc:
                errors.append(str(exc))
        raise ValueError(f"{path} does not match any allowed type: {expected}")
    if expected in JSON_TYPES:
        wanted = JSON_TYPES[expected]
        if expected in {"integer", "number"} and isinstance(value, bool):
            raise ValueError(f"{path} must be {expected}")
        if not isinstance(value, wanted):
            raise ValueError(f"{path} must be {expected}")
    if "enum" in schema and value not in schema["enum"]:
        raise ValueError(f"{path} must be one of {schema['enum']!r}")
    if isinstance(value, dict):
        for required in schema.get("required", []):
            if required not in value:
                raise ValueError(f"Missing required argument: {path}.{required}")
        properties = schema.get("properties", {})
        for key, child in value.items():
            if key in properties:
                validate_value(child, properties[key], f"{path}.{key}")
        if schema.get("additionalProperties") is False:
            unknown = sorted(set(value) - set(properties))
            if unknown:
                raise ValueError(f"Unexpected arguments at {path}: {unknown}")
    if isinstance(value, list) and isinstance(schema.get("items"), dict):
        for index, child in enumerate(value):
            validate_value(child, schema["items"], f"{path}[{index}]")


def scalar_values(value: Any) -> set[str]:
    if isinstance(value, dict):
        return {item for child in value.values() for item in scalar_values(child)}
    if isinstance(value, list):
        return {item for child in value for item in scalar_values(child)}
    if isinstance(value, (str, int, float, bool)):
        return {str(value)}
    return set()


def virtual_result(tool: dict[str, Any], arguments: dict[str, Any]) -> dict[str, Any]:
    """Reproduce the environment-result semantics used to create the trajectories."""
    records = tool.get("data", [])
    name = str(tool["name"])
    if records:
        values = scalar_values(arguments)
        matched = []
        for record in records:
            candidates = {str(record.get("record_id", ""))}
            candidates.update(
                str(value)
                for value in record.get("attributes", {}).values()
                if isinstance(value, (str, int, float, bool))
            )
            if values & candidates:
                matched.append(record)
        if matched:
            returned = matched
        elif name.startswith(("search_", "list_", "web_search")):
            limit = arguments.get("limit")
            returned = records[: int(limit)] if isinstance(limit, int) and limit > 0 else records
        else:
            return {"status": "not_found", "tool": name, "records": []}
        return {"status": "success", "tool": name, "records": returned}

    digest = hashlib.sha256(
        json.dumps({"tool": name, "arguments": arguments}, sort_keys=True).encode()
    ).hexdigest()[:12]
    return {
        "status": "success",
        "tool": name,
        "operation_id": "sim_" + digest,
        "arguments": arguments,
        "message": "Simulated state-changing operation completed.",
    }


class VirtualToolSession:
    def __init__(self, task: dict[str, Any]):
        self.task = task
        self.tools = {str(tool["name"]): tool for tool in task["tools"]}
        self.calls: list[dict[str, Any]] = []
        self.operations: list[dict[str, Any]] = []

    def execute(self, tool_name: str, arguments: dict[str, Any]) -> dict[str, Any]:
        if tool_name not in self.tools:
            raise ValueError(f"Unavailable tool: {tool_name}")
        if not isinstance(arguments, dict):
            raise ValueError("arguments must be a JSON object")
        tool = self.tools[tool_name]
        validate_value(arguments, tool.get("parameters", {"type": "object"}))
        result = virtual_result(tool, arguments)
        call = {
            "call_id": f"call_{len(self.calls):04d}",
            "tool": tool_name,
            "arguments": arguments,
            "result": result,
        }
        self.calls.append(call)
        if "operation_id" in result:
            self.operations.append(call)
        return call

    def state(self) -> dict[str, Any]:
        return {
            "sample_id": self.task["sample_id"],
            "call_count": len(self.calls),
            "simulated_operation_count": len(self.operations),
            "calls": self.calls,
        }


def load_arguments(raw: str) -> dict[str, Any]:
    value = json.loads(raw)
    if not isinstance(value, dict):
        raise ValueError("--arguments must decode to a JSON object")
    return value


def default_tasks_path() -> Path:
    return Path(__file__).resolve().parents[1] / "data/tasks/tasks.jsonl"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--tasks", type=Path, default=default_tasks_path())
    subparsers = parser.add_subparsers(dest="command", required=True)

    list_parser = subparsers.add_parser("list", help="List task identifiers")
    list_parser.add_argument("--limit", type=int, default=20)

    show_parser = subparsers.add_parser("show", help="Show a model-visible task")
    show_parser.add_argument("--sample-id", required=True)

    call_parser = subparsers.add_parser("call", help="Execute one virtual tool call")
    call_parser.add_argument("--sample-id", required=True)
    call_parser.add_argument("--tool", required=True)
    call_parser.add_argument("--arguments", required=True)

    plan_parser = subparsers.add_parser("run-plan", help="Execute a JSON array of tool calls")
    plan_parser.add_argument("--sample-id", required=True)
    plan_parser.add_argument("--plan", type=Path, required=True)
    return parser


def main() -> None:
    args = build_parser().parse_args()
    catalog = TaskCatalog(args.tasks)
    if args.command == "list":
        output: Any = catalog.list(max(0, args.limit))
    elif args.command == "show":
        output = public_task(catalog.get(args.sample_id))
    elif args.command == "call":
        session = VirtualToolSession(catalog.get(args.sample_id))
        output = session.execute(args.tool, load_arguments(args.arguments))
    else:
        plan = json.loads(args.plan.read_text(encoding="utf-8"))
        if not isinstance(plan, list):
            raise ValueError("Plan must be a JSON array")
        session = VirtualToolSession(catalog.get(args.sample_id))
        for index, call in enumerate(plan):
            if not isinstance(call, dict):
                raise ValueError(f"Plan entry {index} must be an object")
            session.execute(str(call.get("tool", "")), call.get("arguments", {}))
        output = session.state()
    json.dump(output, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")


if __name__ == "__main__":
    main()
