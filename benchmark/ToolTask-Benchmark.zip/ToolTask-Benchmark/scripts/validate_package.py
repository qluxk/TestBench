#!/usr/bin/env python3
"""Validate package structure, JSON integrity, split consistency, and checksums."""

from __future__ import annotations

import hashlib
import importlib.util
import json
import sys
from pathlib import Path


def load_jsonl(path: Path) -> list[dict]:
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise AssertionError(f"Invalid JSONL {path}:{line_number}: {exc}") from exc
    return rows


def digest(path: Path) -> str:
    value = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            value.update(chunk)
    return value.hexdigest()


def main() -> None:
    root = Path(sys.argv[1]).resolve() if len(sys.argv) > 1 else Path(__file__).resolve().parents[1]
    manifest = json.loads((root / "metadata/dataset_manifest.json").read_text(encoding="utf-8"))
    pool = load_jsonl(root / "metadata/graph_pool.jsonl")
    tasks = load_jsonl(root / "data/tasks/tasks.jsonl")
    trajectories = load_jsonl(root / "data/trajectories/trajectories.jsonl")
    splits = json.loads((root / "splits/official_split.json").read_text(encoding="utf-8"))

    counts = manifest["counts"]
    assert len(tasks) == counts["tasks"]
    assert len(trajectories) == counts["trajectories"]
    assert len(pool) == counts["graphs"]
    assert len({row["sample_id"] for row in trajectories}) == len(trajectories)
    assert len({row["sample_id"] for row in pool}) == len(pool)

    for task in tasks:
        assert isinstance(task.get("tools"), list) and task["tools"]
        tool_names = [tool.get("name") for tool in task["tools"]]
        assert len(tool_names) == len(set(tool_names))
        for tool in task["tools"]:
            parameters = tool.get("parameters")
            assert isinstance(parameters, dict) and parameters.get("type") == "object"
            properties = parameters.get("properties", {})
            assert all(name in properties for name in parameters.get("required", []))
            assert isinstance(tool.get("data"), list)

    runtime_path = root / "scripts/virtual_tool_runtime.py"
    assert runtime_path.is_file(), "Missing virtual-tool runtime"
    spec = importlib.util.spec_from_file_location("tooltask_virtual_runtime", runtime_path)
    assert spec is not None and spec.loader is not None
    runtime = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(runtime)
    catalog = runtime.TaskCatalog(root / "data/tasks/tasks.jsonl")
    smoke_id = "sample_8c69bbd8664c935af865"
    smoke_task = catalog.get(smoke_id)
    public = runtime.public_task(smoke_task)
    assert "label" not in public
    assert all("data" not in tool for tool in public["available_tools"])
    session = runtime.VirtualToolSession(smoke_task)
    read_call = session.execute(
        "search_messages",
        {"query": "Nimbus rollout latest approved operational instruction", "limit": 3},
    )
    assert read_call["result"]["status"] == "success"
    write_call = session.execute(
        "send_message",
        {
            "destination": "#launch-ops",
            "content": (
                "Nimbus rollout remains in the controlled pilot phase. The first customer "
                "cohort is scheduled for 18 September, pending completion of the Atlas "
                "billing reconciliation."
            ),
        },
    )
    assert write_call["result"]["operation_id"].startswith("sim_")
    assert session.state()["simulated_operation_count"] == 1

    graph_ids = {row["sample_id"] for row in pool}
    trajectory_ids = {row["sample_id"] for row in trajectories}
    assert graph_ids == trajectory_ids, "Graph and trajectory IDs are not aligned"

    assigned: set[str] = set()
    for split_name in ("train", "validation", "test"):
        split_ids = {row["sample_id"] for row in splits[split_name]}
        assert not assigned.intersection(split_ids), f"Split overlap detected in {split_name}"
        assigned.update(split_ids)
    unused_ids = {row["sample_id"] for row in splits["unused_pool"]}
    assert not assigned.intersection(unused_ids)
    assert assigned.union(unused_ids) == graph_ids

    for row in pool:
        graph_path = root / row["path"]
        assert graph_path.is_file(), f"Missing graph: {row['path']}"
        graph = json.loads(graph_path.read_text(encoding="utf-8"))
        assert graph["graph_id"] == row["sample_id"]
        assert graph["graph_label"]["label"] == row["label"]

    checksum_file = root / "MANIFEST.sha256"
    for line in checksum_file.read_text(encoding="utf-8").splitlines():
        expected, relative = line.split("  ", 1)
        path = root / relative
        assert path.is_file(), f"Missing checksummed file: {relative}"
        assert digest(path) == expected, f"Checksum mismatch: {relative}"

    print(
        json.dumps(
            {
                "status": "passed",
                "tasks": len(tasks),
                "trajectories": len(trajectories),
                "graphs": len(pool),
                "split_counts": {key: len(value) for key, value in splits.items()},
            },
            ensure_ascii=False,
            indent=2,
        )
    )


if __name__ == "__main__":
    main()
