#!/usr/bin/env python3
"""Audit semantic DAG structure, hashes, label blindness, and graph vocabulary."""

from __future__ import annotations

import argparse
import hashlib
import json
from collections import Counter
from pathlib import Path
from typing import Any


EDGE_TYPES = {"computes_from", "depends_on", "sequential", "reflects", "branches_from"}


def summarize(paths: list[Path]) -> dict[str, Any]:
    totals = Counter(graphs=0, nodes=0, edges=0, cross_step_edges=0, pure_chains=0, graphs_with_cross_step=0, graphs_with_branch=0, graphs_with_merge=0)
    edge_types: Counter[str] = Counter()
    prompt_versions: Counter[str] = Counter()
    failures: list[str] = []
    for path in paths:
        try:
            graph = json.loads(path.read_text(encoding="utf-8"))
            nodes, edges = graph["nodes"], graph["edges"]
            generation = graph["two_stage_edge_generation"]
            pairs = [(int(edge["from"]), int(edge["to"])) for edge in edges]
            if any(not 1 <= start < end <= len(nodes) for start, end in pairs):
                raise ValueError("non-forward edge")
            if len(pairs) != len(set(pairs)):
                raise ValueError("duplicate edge pair")
            if any(edge["type"] not in EDGE_TYPES for edge in edges):
                raise ValueError("unknown edge type")
            if any(node["raw_content_sha256"] != hashlib.sha256(node["raw_content"].encode("utf-8")).hexdigest() for node in nodes):
                raise ValueError("node content hash mismatch")
            incoming = Counter(end for _, end in pairs)
            if any(incoming[node] == 0 for node in range(2, len(nodes) + 1)):
                raise ValueError("node without parent")
            if not generation["validation"]["labels_excluded_from_prompts"]:
                raise ValueError("label-blind validation is false")
            outdegree = Counter(start for start, _ in pairs)
            cross = sum(end != start + 1 for start, end in pairs)
            pure_chain = len(edges) == len(nodes) - 1 and all(pair == (index, index + 1) for index, pair in enumerate(pairs, 1))
            totals.update(graphs=1, nodes=len(nodes), edges=len(edges), cross_step_edges=cross, pure_chains=int(pure_chain), graphs_with_cross_step=int(cross > 0), graphs_with_branch=int(any(value > 1 for value in outdegree.values())), graphs_with_merge=int(any(value > 1 for value in incoming.values())))
            edge_types.update(edge["type"] for edge in edges)
            prompt_versions[generation["prompt_version"]] += 1
        except Exception as exc:
            failures.append(f"{path}: {type(exc).__name__}: {exc}")
    graphs = totals["graphs"]
    return {
        **totals,
        "pure_chain_rate": totals["pure_chains"] / graphs if graphs else None,
        "cross_step_graph_rate": totals["graphs_with_cross_step"] / graphs if graphs else None,
        "branch_graph_rate": totals["graphs_with_branch"] / graphs if graphs else None,
        "merge_graph_rate": totals["graphs_with_merge"] / graphs if graphs else None,
        "edge_types": dict(edge_types),
        "prompt_versions": dict(prompt_versions),
        "validation_failures": failures,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("graph_dir", type=Path)
    parser.add_argument("--output", type=Path)
    parser.add_argument("--max-pure-chain-rate", type=float, default=0.35)
    parser.add_argument("--min-cross-step-graph-rate", type=float, default=0.60)
    args = parser.parse_args()
    report = {
        label: summarize(sorted((args.graph_dir / label).glob("graph_*.json")))
        for label in ("normal", "abnormal")
    }
    populated = [label for label in ("normal", "abnormal") if report[label]["graphs"] > 0]
    report["gate"] = {
        "max_pure_chain_rate": args.max_pure_chain_rate,
        "min_cross_step_graph_rate": args.min_cross_step_graph_rate,
        "passed": bool(populated) and all(
            not report[label]["validation_failures"]
            and report[label]["pure_chain_rate"] <= args.max_pure_chain_rate
            and report[label]["cross_step_graph_rate"] >= args.min_cross_step_graph_rate
            for label in populated
        ),
    }
    text = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    if args.output:
        args.output.write_text(text, encoding="utf-8")
    print(text, end="")
    if not report["gate"]["passed"]:
        raise SystemExit("semantic structure gate failed")


if __name__ == "__main__":
    main()
