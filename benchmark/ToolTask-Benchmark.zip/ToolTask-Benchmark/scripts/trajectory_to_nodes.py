#!/usr/bin/env python3
"""Convert ToolTask trajectories into lossless ordered nodes and a base graph."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Any


NODE_TYPES = {"Problem", "Thinking", "Action", "State"}


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def append_node(
    nodes: list[dict[str, Any]],
    node_type: str,
    content: Any,
    source_path: str,
    metadata: dict[str, Any],
) -> None:
    text = str(content).strip()
    if not text:
        return
    sequence = len(nodes) + 1
    nodes.append(
        {
            "id": f"node_{sequence:04d}",
            "sequence": sequence,
            "type": node_type,
            "raw_content": text,
            "raw_content_sha256": sha256_text(text),
            "source_path": source_path,
            "metadata": metadata,
        }
    )


def build_nodes(row: dict[str, Any]) -> list[dict[str, Any]]:
    nodes: list[dict[str, Any]] = []
    for index, step in enumerate(row["steps"]):
        role = str(step.get("role", "")).strip().lower()
        base = {"role": role, "turn_index": index}
        if role == "user":
            append_node(nodes, "Problem", step.get("content", ""), f"steps[{index}].content", {**base, "state_kind": "problem"})
        elif role == "agent":
            append_node(nodes, "Thinking", step.get("thought", ""), f"steps[{index}].thought", {**base, "state_kind": "reasoning"})
            append_node(nodes, "Action", step.get("action", ""), f"steps[{index}].action", {**base, "state_kind": "tool_call"})
            append_node(nodes, "State", step.get("content", ""), f"steps[{index}].content", {**base, "state_kind": "final_answer"})
        elif role == "environment":
            append_node(nodes, "State", step.get("content", ""), f"steps[{index}].content", {**base, "state_kind": "tool_output"})
        else:
            append_node(nodes, "State", step.get("content", ""), f"steps[{index}].content", {**base, "state_kind": "other"})
    if not nodes:
        raise ValueError(f"{row.get('sample_id')}: trajectory has no non-empty nodes")
    return nodes


def resolved_label(row: dict[str, Any]) -> tuple[int, str, int]:
    outcome = str(row.get("outcome_label", "")).strip().lower()
    if outcome not in {"clean", "defended", "compromised"}:
        raise ValueError(f"{row.get('sample_id')}: unresolved outcome {outcome!r}")
    expected = 1 if outcome == "compromised" else 0
    label = row.get("label")
    if label != expected:
        raise ValueError(f"{row.get('sample_id')}: label conflicts with outcome")
    exposure = row.get("source_attack_exposure_label")
    if exposure not in (0, 1):
        raise ValueError(f"{row.get('sample_id')}: invalid attack-exposure label")
    return expected, outcome, int(exposure)


def build_base_graph(row: dict[str, Any], source_name: str) -> dict[str, Any]:
    label, outcome, exposure = resolved_label(row)
    nodes = build_nodes(row)
    return {
        "graph_id": row["sample_id"],
        "source_trajectory": source_name,
        "mapping_model": "deterministic_lossless_node_mapping_v1",
        "node_types": ["Problem", "Thinking", "Action", "State"],
        "nodes": nodes,
        "edges": [],
        "task_id": row["pair_key"],
        "domain": row["domain"],
        "task": row["task"],
        "graph_label": {
            "label": label,
            "policy": "compromised_outcome_binary",
            "outcome": outcome,
            "outcome_class": {"clean": 0, "defended": 1, "compromised": 2}[outcome],
            "source_attack_exposure_label": exposure,
        },
        "trajectory_metadata": {
            "sample_id": row["sample_id"],
            "pair_key": row["pair_key"],
            "domain": row["domain"],
            "num_steps": len(row["steps"]),
            "provenance_metadata_withheld": True,
        },
        "integrity": {
            "lossless_nonempty_fields": True,
            "node_count": len(nodes),
            "edge_count": 0,
            "order_preserved": True,
            "content_rewritten": False,
            "empty_fields_omitted": True,
            "forward_only": True,
            "acyclic": True,
        },
    }


def load_jsonl(path: Path) -> list[dict[str, Any]]:
    rows = []
    with path.open("r", encoding="utf-8") as handle:
        for line_number, line in enumerate(handle, 1):
            if not line.strip():
                continue
            try:
                rows.append(json.loads(line))
            except json.JSONDecodeError as exc:
                raise ValueError(f"Invalid JSONL at {path}:{line_number}: {exc}") from exc
    return rows
