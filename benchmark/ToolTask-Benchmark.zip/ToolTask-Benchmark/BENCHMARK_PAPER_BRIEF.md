# Benchmark Paper Brief

## Central benchmark claim

Tool-use security should be evaluated at three aligned representation levels: task/tool records, complete execution trajectories, and directed semantic trajectory graphs. The benchmark separates attack exposure from compromised outcome and preserves task identity for leakage-aware evaluation.

This is a proposed paper claim. It must be supported by the experiments below and must be narrowed if the evidence is incomplete.

## Benchmark questions

1. How difficult is compromised-outcome detection from task records, trajectories, and graphs?
2. Which representation level provides the most useful signal under a shared data split?
3. Do methods generalize across task domains and attack mechanisms?
4. Can a method localize the risky Action rather than only classify the full trajectory?
5. Which dataset artifacts or shortcut features influence performance?

## Minimum experimental package

### Main comparison

Evaluate simple text classifiers, sequence encoders, standard graph neural networks, relation/edge-aware graph models, graph anomaly detectors, guard models, and LLM judges. Group methods by input modality and report compute or API cost separately.

### Difficulty and diversity

Report results by domain, trajectory length, graph size, number of Actions, attack family, and task complexity. Include class-ratio sensitivity without changing the frozen official test set.

### Leakage and shortcut checks

- Enforce task-group separation across splits.
- Check duplicate and near-duplicate tasks, trajectories, node text, and graph structures.
- Mask label-like words and compare performance.
- Compare original identifiers with neutralized identifiers.
- Train on one domain and evaluate on held-out domains.
- Test whether graph topology alone or text alone predicts labels.

### Localization

Report Action Hit@1, Hit@K, candidate recall, node/edge IoU, localization size, and representative success/failure cases. Candidate coverage must not be presented as localization accuracy.

### Annotation and graph quality

Audit outcome-label agreement on a stratified sample. Audit graph faithfulness, semantic-edge validity, direction, disconnected components, pure chains, branches, and merges. Report the sampling protocol and adjudication process.

### Robustness and cost

Measure random-seed variation, threshold sensitivity, calibration, inference latency, memory, token cost where applicable, and behavior under alternative anomaly prevalence.

## Required tables

- Dataset statistics and domain distribution.
- Task/trajectory/graph schema comparison.
- Main benchmark results grouped by input modality.
- Cross-domain and attack-family generalization.
- Leakage and shortcut diagnostics.
- Localization results.
- Efficiency and cost.
- Human or expert audit results.

## Claims that require evidence

Do not claim that the benchmark is realistic, diverse, leakage-free, difficult, comprehensive, or predictive of real deployment without a corresponding audit or experiment. Do not claim state-of-the-art performance unless the comparison protocol and public baselines are verified.

## Paper structure

1. Introduction
2. Threat model and benchmark scope
3. Dataset construction
4. Task, trajectory, and graph schemas
5. Quality control and leakage audit
6. Benchmark tasks and metrics
7. Baselines and implementation
8. Main results
9. Generalization, localization, and shortcut analysis
10. Limitations, ethics, and maintenance
11. Conclusion
